import java.io.*;
import java.util.*;
import javax.comm.*;



/**
 * This class is a driver for the "TH-03 Temperature to PC Data Logger" from Pico Technologies Limited.
 * (http://www.picotech.com).
 * It requires a javax.comm api implementation, which can be found (Windows version) at:
 * http://java.sun.com/products/javacomm/downloads/index.html
 * @author Morten Krogh Andersen (morten@krogh.net)
 */
public class TH_03 {

	private final byte CMD_GET_VERSION	= 0x01;
	private final byte CMD_GET_LOW_REF	= 0x02;
	private final byte CMD_GET_HIGH_REF	= 0x03;
	private final byte CMD_GET_CH_1		= 0x04;
	private final byte CMD_GET_CH_2		= 0x08;
	private final byte CMD_GET_CH_3		= 0x0C;
	
	private final int BASE_REF_LOW		= 20082;
	private final int BASE_REF_HIGH		= 43773;

	private final int COMM_TIMEOUT_MS	= 2000;

	private final int BUFFER_LENGTH		= 5;

	private byte[] buffer;
	private SerialPort serialPort;
	private BufferedInputStream in;
	private BufferedOutputStream out;

	private int refLow;
	private int refHigh;
	private int prevTemp;

	/**
	 * Initializes the unit by providing power and giving it time to start up.
	 * The duration of this constructor is approx. one second, because it waits for the unit to start up. (Using Thread.sleep())
	 * @param serialPortName	The name of the serial port to which the unit is connected.
	 * 							In Windows this will typically be COM1 og COM2.
	 * 							Don't expect USB to serial converters to work, since these often do not
	 * 							provide DTR, which is essential to power the unit.
	 * 							This shouldn't be a problem when using an external PSU for the unit, but 
	 * 							I haven't tried this. 
	 * @throws Exception		If any Exception occurs some error text is printed to stdout, and the Exception
	 * 							is rethrown. This isn't pretty, but is done to avoid inventing a new Exception type.
	 */
	public TH_03(String serialPortName) throws Exception {

		try {
			CommPortIdentifier portId = CommPortIdentifier.getPortIdentifier(serialPortName);
			if(portId.getPortType() != CommPortIdentifier.PORT_SERIAL) throw new Exception();

			serialPort	= (SerialPort)portId.open("onk.tempsurvey.client.tempclient.comm.TH_03",30);

			serialPort.setSerialPortParams(2400, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
			serialPort.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);

			out = new BufferedOutputStream(this.serialPort.getOutputStream());
			in = new BufferedInputStream(this.serialPort.getInputStream());

			// Provide power for the TH03 unit
			serialPort.setRTS(true);
			serialPort.setDTR(false);
			// Wait for the unit to settle
			// Waiting "More than one sec." as required according to the documentation for the TH-30)
			Thread.sleep(1100);
			
			buffer	= new byte[BUFFER_LENGTH];
		} catch (Exception e) {
			System.out.println("Unable to aquire serial port - zero temperature ports available");
			System.out.println("Available serial ports:");
			Enumeration portIds = CommPortIdentifier.getPortIdentifiers();
			CommPortIdentifier port;
			while(portIds.hasMoreElements()) {
				port = (CommPortIdentifier)portIds.nextElement();
				if(port.getPortType() == CommPortIdentifier.PORT_SERIAL)
					System.out.println(port.getName());
			}
			serialPort = null;
			throw e;
		}
	}

	/**
	 * Attempting to communicate with the unit by getting its software version.
	 * This method is for convenience only, and is not nescessary for the unit to function.
	 * @return true if the unit wasn't found on the serial port, or if some serial port error occured.
	 */
	public boolean initialize() {
		boolean result = false;
		//Initialize
		if(serialPort != null) {
			try {
				// First reading is always zero, for some reason that I'm not going to figure out now.
				Arrays.fill(buffer, (byte)0x00);
				out.write(CMD_GET_VERSION);
				out.flush();
				waitForData(COMM_TIMEOUT_MS);

				// Get the version of the unit, in order to assure that the unit is available on the serial port.
				Arrays.fill(buffer, (byte)0x00);
				out.write(CMD_GET_VERSION);
				out.flush();
				if(waitForData(COMM_TIMEOUT_MS) == 0) {
					result = false;
				} else {
					// Yes, sout's aren't nice, but this is not a production class..
					System.out.println("TH-03 initialized. Unit version: " + buffer[0]);
					result = true;
				}
			} catch (IOException e) {
				result = false;
			}
		}
		return result;
	}
	
	
	/**
	 * Converts the two byte value from the TH-03 to an integer.
	 * @param hexNumber first byte must be the high byte and second mut the low byte of the value.
	 * @return The two bytes converted to an integer.
	 */
	private int bytes2Number(byte[] hexNumber) {
		int hi = hexNumber[0];
		int lo = hexNumber[1];
		if(hi<0) hi += 256;
		if(lo<0) lo += 256;
		return (hi<<8)+lo;
	}

	/**
	 * Waits for data from the serial port for the specified amount of time.
	 * @param timeoutMillis the amount of miliseconds to wait for data.
	 * @return The amount of data read from the serial port, zero if the specified time elapsed.
	 * @throws IOException
	 */
	private int waitForData(long timeoutMillis) throws IOException {
		long stopTime = System.currentTimeMillis()+timeoutMillis;
		while(stopTime>System.currentTimeMillis())
			if(in.available() > 0)
				return in.read(buffer);
		return 0;
	}

	/**
	 * Reads the temperature from the specified port.
	 * @return The temperature read - in celcius.
	 * @param portNum The number of the temperature port to read from.
	 * Available ports are: 1,2 and 3 - if any other number is specified, port number one is read.  
	 */
	double getTemperature(int portNum) {

		if(serialPort == null) return 0.0;
		
		try {
			//Get high reference 
			Arrays.fill(buffer, (byte)0x00);
			out.write(CMD_GET_HIGH_REF);
			out.flush();
			if(waitForData(COMM_TIMEOUT_MS) == 0) return number2Temp(prevTemp);
			refHigh = bytes2Number(buffer);

			// Get low reference
			Arrays.fill(buffer, (byte)0x00);
			out.write(CMD_GET_LOW_REF);
			out.flush();
			if(waitForData(COMM_TIMEOUT_MS) == 0) return number2Temp(prevTemp);
			refLow = bytes2Number(buffer);

			// Get temperature
			Arrays.fill(buffer, (byte)0x00);
			switch(portNum) {
				case 3:
					out.write(CMD_GET_CH_3);
					break;
				case 2:
					out.write(CMD_GET_CH_2);
					break;
				default: // Read from port 1
					out.write(CMD_GET_CH_1);
			}
			out.flush();
			if(waitForData(COMM_TIMEOUT_MS) == 0) return number2Temp(prevTemp);
		} catch (IOException e) {
			return number2Temp(prevTemp);
		}

		// Correct the ad value according to the new high and low reference values.
		prevTemp = BASE_REF_LOW + (bytes2Number(buffer)-refLow)*(BASE_REF_HIGH-BASE_REF_LOW)/(refHigh-refLow);
		
		return number2Temp(prevTemp);
	}

	/**
	 * Convert the calculated AD value, read from the TH-03, 
	 * to a temperature on the Celcius scale, using a table from the TH-03 documentation.
	 */
	private double number2Temp(int adValue) {
	
		int cnt = 0;
	
		// Find the first value
		while(AD_VALUES[cnt++] > adValue)
			if(cnt >= AD_VALUES.length) // If the ad value is smaller than the smallest value in the array
				return (double)(AD_VALUES.length-1);

		if(cnt==1) // If the ad value is larger than the largest value in the array
			return 0.0;

		cnt -= 2;

		// Calculate the temperature from the AD values found
		return (cnt+((1.0/(AD_VALUES[cnt]-AD_VALUES[cnt+1]))*(AD_VALUES[cnt]-adValue)));
	}
	
	// Contains AD offset values. Used for converting the read AD value to a temperature in Celcius.
	private final int[] AD_VALUES = {
		29219,
		28840,
		28467,
		28099,
		27738,
		27380,
		27031,
		26690,
		26355,
		26027,
		25705, // 10
		25392,
		25087,
		24789,
		24498,
		24214,
		23939,
		23671,
		23411,
		23158,
		22911, // 20
		22673,
		22442,
		22218,
		22002,
		21790,
		21587,
		21390,
		21200,
		21016,
		20837, // 30
		20665,
		20499,
		20339,
		20184,
		20034,
		19889,
		19750,
		19616,
		19486,
		19360  // 40
	};

} // end TH_03