/*
 * th03TestApp.java
 *
 * This is a test application showing how to use the TH03 driver class
 * made by Morten Krag Andersen and Thomas Braad Toft from, IHA.
 * Thanks for the contribution.
 * Please be sure to mention in your report and source code were the code was
 * taken from.
 *
 * In order to get this unit to work - you will also need to download the
 * Java Communications API for your specific platform.
 *
 * The following description applies only for the Windows PC platform.
 *
 * Installation:
 * Download (or use the provided implementation) the API from:
 * http://java.sun.com/products/javacomm/
 * Unzip the API
 * Copy win32com.dll to your <JDK>\bin directory.
 * Copy comm.jar to your <JDK>\lib directory.
 * Copy javax.comm.properties to your <JDK>\lib directory.
 * Add comm.jar to your classpath
 * e.g. C:\>set CLASSPATH=c:\<JDK>\lib\comm.jar;%classpath%
 * Now you should be able to use the TH03 class
 * Consider wrapping it in a package - example th03.driver
 *
 * This application may be run by simply typing: java TH03TestApp
 * Created on 28. april 2004, 10:56
 */

/**
 *
 * @author  Stefan Wagner, IHA
 */
public class TH03TestApp {
    
    public static void main(String[] args) {
        try {
            // Make an instance of the driver
            // It has been hardcoded to COM1 - please change if nessecary
            TH_03 pico = new TH_03("COM1");
            // Initialize the driver
            pico.initialize();
            // make 20 readings
            for (int i=0; i<10; i++) {
            // Read the temperature of the driver
            double tempReading = pico.getTemperature(1);
            // Output the reading
            System.out.println("Tempreading nr.: "+(i+1)+" value: "+tempReading);
            }
        } catch (Exception e) {
            //Different exceptions might occur - see the TH_03 class
            e.printStackTrace();
        }
    }
    
}
