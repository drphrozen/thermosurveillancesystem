Dette er en kort vejledning til at f� TH03 Java driveren til at virke. 
Driveren er udviklet af Morten Krag Andersen og Thomas Braad Toft.

Driveren best�r af Java filen TH03.java og den tilh�rende .class fil i compileret udgave.

Under folderen \exampleApp\ findes der en testapplikation der illustrerer brugen af driveren.

Bem�rk at der skal installeres det eksterne Java Communications API.

Jeg har downloadet API'et for jer (det ligger i commapi.zip) inkl. en .dll til brug for mapningen af den serielle port.
Dog kun i PC udgaven. �nsker du at benytte dette under f.eks. LINUX s� se PicoInstrukser.txt

Installation af API'et under Windows er som f�lger:

 * Installation:
 * Download (or use the provided implementation) the API from:
 * http://java.sun.com/products/javacomm/
 * Unzip the API
 * Copy win32com.dll to your <JDK>\bin directory.
 * Copy comm.jar to your <JDK>\lib directory.
 * Copy javax.comm.properties to your <JDK>\lib directory.
 * Add comm.jar to your classpath
 * e.g. C:\>set CLASSPATH=c:\<JDK>\lib\comm.jar;%classpath%
 * Now you should be able to use the TH03 class
 * Consider wrapping it in a package - example th03.driver

Efter disse skridt er p� plads burde du kunne kompilere exampleApp\TH03TestApp.java programmet og afvikle det.

God forn�jelse.
